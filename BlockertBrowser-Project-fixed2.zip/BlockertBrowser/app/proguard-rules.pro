# GeckoView contains native JNI entry points. Keep its public API and JNI-backed classes.
-keep class org.mozilla.geckoview.** { *; }
-dontwarn org.mozilla.geckoview.**
