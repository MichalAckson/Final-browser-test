package com.chatgpt.blockertbrowser

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient.FileChooserParams
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebResponse
import java.io.InputStream
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Blockert Browser: a native Android browser shell.
 * Default renderer is Mozilla GeckoView. Android System WebView is an optional fallback.
 * The application owns tabs, chrome UI, history, bookmarks, saved sessions and downloads.
 */
class MainActivity : Activity() {
    companion object {
        private const val PREFS = "blockert_browser_store"
        private const val HOME_URL = "https://www.google.com/"
        private const val ENGINE_GECKO = "gecko"
        private const val ENGINE_SYSTEM = "system_webview"
        private const val REQUEST_FILE_CHOOSER = 41
        private const val REQUEST_EXPORT = 42
        private const val MAX_HISTORY = 500

        @Volatile private var sharedGeckoRuntime: GeckoRuntime? = null
    }

    private class BrowserTab(var id: String, var engine: String) {
        var title: String = "New block"
        var url: String = HOME_URL
        var savedGeckoState: String? = null
        var view: View? = null
        var geckoSession: GeckoSession? = null
        var webView: WebView? = null
        var canGoBack: Boolean = false
        var canGoForward: Boolean = false
    }

    private data class StoredDownload(val uri: String, val name: String, val mime: String)

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab: BrowserTab? = null
    private lateinit var root: LinearLayout
    private lateinit var browserArea: FrameLayout
    private lateinit var addressBar: EditText
    private lateinit var tabCountButton: Button
    private lateinit var pageProgress: ProgressBar
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var exportSource: Uri? = null
    private var exportName: String = "download"
    private var geckoRuntime: GeckoRuntime? = null

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val dm by lazy { getSystemService(DOWNLOAD_SERVICE) as DownloadManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = color(R.color.grass_dark)
        window.navigationBarColor = color(R.color.ink)
        window.decorView.systemUiVisibility = 0
        try {
            geckoRuntime = sharedGeckoRuntime ?: GeckoRuntime.create(applicationContext).also {
                sharedGeckoRuntime = it
            }
        } catch (_: Throwable) {
            geckoRuntime = null
        }
        buildUi()
        restoreTabs()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(R.color.ink))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(3), dp(4), dp(7))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandText.addView(label("BLOCKERT BROWSER", 16, color(R.color.paper), true))
        brandText.addView(label("MINECRAFT-INSPIRED WEB EXPLORER", 9, color(R.color.grass_light), true))
        val brandParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        brandParams.marginStart = dp(9)
        brandRow.addView(brandText, brandParams)
        brandRow.addView(actionButton("⚙", color(R.color.stone), color(R.color.paper)) { showEngineDialog() })
        root.addView(brandRow)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        addressBar = EditText(this).apply {
            setSingleLine(true)
            textSize = 14f
            setTextColor(color(R.color.ink))
            setHintTextColor(0xff637166.toInt())
            hint = "Search or enter address"
            setPadding(dp(12), 0, dp(10), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            background = blockDrawable(color(R.color.paper), color(R.color.grass_light))
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigateFromAddress(); true
                } else false
            }
        }
        addressRow.addView(addressBar, LinearLayout.LayoutParams(0, dp(48), 1f))
        val go = actionButton("GO", color(R.color.grass), Color.WHITE) { navigateFromAddress() }
        val goParams = LinearLayout.LayoutParams(dp(58), dp(48))
        goParams.marginStart = dp(6)
        addressRow.addView(go, goParams)
        root.addView(addressRow)

        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(5))
        }
        navRow.addView(actionButton("◀", color(R.color.stone), color(R.color.paper)) { goBack() })
        navRow.addView(actionButton("▶", color(R.color.stone), color(R.color.paper)) { goForward() })
        navRow.addView(actionButton("↻", color(R.color.stone), color(R.color.paper)) { reload() })
        navRow.addView(actionButton("⌂", color(R.color.stone), color(R.color.paper)) { loadInActive(HOME_URL) })
        navRow.addView(actionButton("★", color(R.color.dirt), color(R.color.paper)) { addBookmark() })
        val spacer = View(this)
        navRow.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        tabCountButton = actionButton("1 TAB", color(R.color.grass), Color.WHITE) { showTabSwitcher() }
        navRow.addView(tabCountButton)
        navRow.addView(actionButton("+", color(R.color.grass_light), color(R.color.ink)) { newTab() })
        root.addView(navRow)

        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(color(R.color.grass_light))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.stone))
        }
        root.addView(pageProgress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        browserArea = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(browserArea, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        bottom.addView(bottomButton("TABS", "▦") { showTabSwitcher() })
        bottom.addView(bottomButton("HISTORY", "◷") { showHistory() })
        bottom.addView(bottomButton("BOOKMARKS", "★") { showBookmarks() })
        bottom.addView(bottomButton("DOWNLOADS", "↓") { showDownloads() })
        bottom.addView(bottomButton("SESSIONS", "▣") { showSessions() })
        root.addView(bottom)
        setContentView(root)
    }

    private fun restoreTabs() {
        val json = prefs.getString("open_tabs", null)
        var restored = false
        if (!json.isNullOrBlank()) {
            try {
                val array = JSONArray(json)
                val savedActive = prefs.getString("active_tab", null)
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val id = item.optString("id", UUID.randomUUID().toString())
                    val url = item.optString("url", HOME_URL)
                    val engine = item.optString("engine", prefs.getString("engine", ENGINE_GECKO) ?: ENGINE_GECKO)
                    val state = item.optString("state", "").takeIf { it.isNotBlank() }
                    val tab = createTab(url, false, engine, state, loadNow = state == null)
                    // Keep the same live object: Gecko delegates capture this instance.
                    tab.id = id
                    tab.title = item.optString("title", url)
                    if (id == savedActive) activeTab = tab
                    restored = true
                }
                if (activeTab == null) activeTab = tabs.firstOrNull()
            } catch (_: Throwable) {
                tabs.clear()
                activeTab = null
            }
        }
        if (!restored || tabs.isEmpty()) {
            activeTab = null
            createTab(HOME_URL, true, preferredEngine(), null, true)
        } else {
            activateTab(activeTab ?: tabs.first())
        }
        refreshTabCount()
        persistTabs()
    }


    private fun createTab(
        initialUrl: String,
        activate: Boolean,
        engine: String,
        savedState: String? = null,
        loadNow: Boolean = true
    ): BrowserTab {
        val tab = BrowserTab(UUID.randomUUID().toString(), engine)
        tab.url = initialUrl.ifBlank { HOME_URL }
        tab.savedGeckoState = savedState
        if (engine == ENGINE_GECKO && geckoRuntime != null) {
            createGeckoSurface(tab, savedState, loadNow)
        } else {
            tabFallbackToSystem(tab, initialUrl, loadNow)
        }
        tabs.add(tab)
        if (activate) activateTab(tab) else tab.geckoSession?.setActive(false)
        refreshTabCount()
        persistTabs()
        return tab
    }

    private fun createGeckoSurface(tab: BrowserTab, savedState: String?, loadNow: Boolean) {
        val session = GeckoSession()
        val view = GeckoView(this)
        tab.geckoSession = session
        tab.view = view
        session.open(geckoRuntime!!)
        session.setContentDelegate(object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title?.takeIf { it.isNotBlank() } ?: tab.url
                if (activeTab === tab) refreshTabCount()
                persistTabs()
            }
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                saveGeckoResponse(response)
            }
            override fun onCloseRequest(session: GeckoSession) {
                closeTab(tab.id)
            }
        })
        session.setNavigationDelegate(object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (!url.isNullOrBlank()) {
                    tab.url = url
                    if (activeTab === tab) addressBar.setText(url)
                    recordHistory(tab.title, url)
                    persistTabs()
                }
            }
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack
            }
            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tab.canGoForward = canGoForward
            }
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession> {
                val new = createTab(uri, false, ENGINE_GECKO, null, loadNow = false)
                activateTab(new)
                return GeckoResult.fromValue(new.geckoSession!!)
            }
        })
        session.setProgressDelegate(object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                if (activeTab === tab) pageProgress.visibility = View.VISIBLE
            }
            override fun onPageStop(session: GeckoSession, success: Boolean) {
                if (activeTab === tab) pageProgress.visibility = View.GONE
            }
            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (activeTab === tab) pageProgress.progress = progress
            }
            override fun onSessionStateChange(session: GeckoSession, state: GeckoSession.SessionState) {
                tab.savedGeckoState = state.toString()
                persistTabs()
            }
        })
        view.setSession(session)
        if (!savedState.isNullOrBlank()) {
            try {
                val restored = GeckoSession.SessionState.fromString(savedState)
                if (restored != null) session.restoreState(restored)
                else if (loadNow && initialUrlIsHttp(tab.url)) session.loadUri(tab.url)
            } catch (_: Throwable) {
                if (loadNow && initialUrlIsHttp(tab.url)) session.loadUri(tab.url)
            }
        } else if (loadNow && initialUrlIsHttp(tab.url)) {
            session.loadUri(tab.url)
        }
    }

    private fun tabFallbackToSystem(tab: BrowserTab, initialUrl: String, loadNow: Boolean) {
        tab.engine = ENGINE_SYSTEM
        tab.title = if (initialUrl.isBlank()) "New block" else initialUrl
        val web = WebView(this)
        tab.webView = web
        tab.view = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "http" || uri.scheme == "https") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                } catch (_: Throwable) { true }
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                tab.url = url
                if (activeTab === tab) {
                    addressBar.setText(url)
                    pageProgress.visibility = View.VISIBLE
                }
            }
            override fun onPageFinished(view: WebView, url: String) {
                tab.url = url
                tab.title = view.title?.takeIf { it.isNotBlank() } ?: url
                tab.canGoBack = view.canGoBack()
                tab.canGoForward = view.canGoForward()
                if (activeTab === tab) pageProgress.visibility = View.GONE
                recordHistory(tab.title, url)
                persistTabs()
            }
            override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                handler.cancel()
            }
            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                Toast.makeText(this@MainActivity, "A page renderer stopped. Reopen this tab to continue.", Toast.LENGTH_LONG).show()
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), REQUEST_FILE_CHOOSER)
                    true
                } catch (_: Throwable) {
                    fileChooserCallback = null
                    false
                }
            }
        }
        web.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            queueWebViewDownload(url, userAgent, contentDisposition, mimeType)
        })
        if (loadNow && initialUrl.isNotBlank()) web.loadUrl(initialUrl)
    }

    private fun activateTab(tab: BrowserTab) {
        val old = activeTab
        if (old !== tab) old?.geckoSession?.setActive(false)
        activeTab = tab
        browserArea.removeAllViews()
        tab.view?.let { browserArea.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        tab.geckoSession?.setActive(true)
        addressBar.setText(tab.url)
        refreshTabCount()
        persistTabs()
    }

    private fun newTab() {
        createTab(HOME_URL, true, preferredEngine(), null, true)
    }

    private fun closeTab(id: String) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val tab = tabs.removeAt(index)
        try { tab.geckoSession?.close() } catch (_: Throwable) {}
        try { tab.webView?.stopLoading(); tab.webView?.destroy() } catch (_: Throwable) {}
        if (activeTab === tab) {
            activeTab = null
            if (tabs.isEmpty()) createTab(HOME_URL, true, preferredEngine(), null, true)
            else activateTab(tabs[(index - 1).coerceAtLeast(0).coerceAtMost(tabs.lastIndex)])
        }
        refreshTabCount()
        persistTabs()
    }

    private fun refreshTabCount() {
        tabCountButton.text = "${tabs.size} TAB${if (tabs.size == 1) "" else "S"}"
    }

    private fun navigateFromAddress() {
        val raw = addressBar.text.toString().trim()
        if (raw.isBlank()) return
        val target = normalizeInput(raw)
        loadInActive(target)
    }

    private fun normalizeInput(raw: String): String {
        if (raw.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) return raw
        if (raw.contains(' ') || !raw.contains('.')) {
            return "https://www.google.com/search?q=" + Uri.encode(raw)
        }
        return "https://$raw"
    }

    private fun initialUrlIsHttp(url: String) = url.startsWith("http://") || url.startsWith("https://")

    private fun loadInActive(url: String) {
        val tab = activeTab ?: return
        tab.url = url
        addressBar.setText(url)
        if (tab.geckoSession != null) tab.geckoSession?.loadUri(url)
        else tab.webView?.loadUrl(url)
        persistTabs()
    }

    private fun goBack() {
        val tab = activeTab ?: return
        if (tab.geckoSession != null) {
            if (tab.canGoBack) tab.geckoSession?.goBack()
        } else if (tab.webView?.canGoBack() == true) tab.webView?.goBack()
    }

    private fun goForward() {
        val tab = activeTab ?: return
        if (tab.geckoSession != null) {
            if (tab.canGoForward) tab.geckoSession?.goForward()
        } else if (tab.webView?.canGoForward() == true) tab.webView?.goForward()
    }

    private fun reload() {
        val tab = activeTab ?: return
        if (tab.geckoSession != null) tab.geckoSession?.reload() else tab.webView?.reload()
    }

    private fun showTabSwitcher() {
        val content = dialogContent()
        tabs.forEachIndexed { index, tab ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = blockDrawable(if (tab === activeTab) color(R.color.grass_dark) else color(R.color.stone), color(R.color.grass))
            }
            card.addView(label("BLOCK ${index + 1}", 10, color(R.color.grass_light), true))
            card.addView(label(tab.title.ifBlank { "New block" }, 14, color(R.color.paper), true))
            card.addView(label(tab.url, 10, 0xffc5d0c7.toInt(), false))
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
            buttons.addView(actionButton("SWITCH", color(R.color.grass), Color.WHITE) {
                activateTab(tab); showToast("Switched to block ${index + 1}");
            })
            buttons.addView(actionButton("✕", color(R.color.dirt), Color.WHITE) { closeTab(tab.id); showTabSwitcher() })
            card.addView(buttons)
            val params = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(8)
            content.second.addView(card, params)
        }
        AlertDialog.Builder(this).setTitle("Your blocks · ${tabs.size}").setView(content.first)
            .setPositiveButton("+ NEW TAB") { _, _ -> newTab() }
            .setNegativeButton("CLOSE", null).show()
    }

    private fun showHistory() {
        val content = dialogContent()
        val history = loadArray("history")
        if (history.length() == 0) content.second.addView(label("No browsing history yet.", 13, color(R.color.paper), false))
        for (i in history.length() - 1 downTo 0) {
            val item = history.optJSONObject(i) ?: continue
            val url = item.optString("url")
            val title = item.optString("title", url)
            val time = item.optLong("time", 0L)
            content.second.addView(listRow(title, "$url\n${DateFormat.getDateTimeInstance().format(Date(time))}") {
                loadInActive(url)
            })
        }
        AlertDialog.Builder(this).setTitle("Trail map · History").setView(content.first)
            .setNeutralButton("CLEAR HISTORY") { _, _ -> prefs.edit().remove("history").apply(); showToast("History cleared") }
            .setNegativeButton("DONE", null).show()
    }

    private fun addBookmark() {
        val tab = activeTab ?: return
        if (!initialUrlIsHttp(tab.url)) return
        val bookmarks = loadArray("bookmarks")
        for (i in 0 until bookmarks.length()) if (bookmarks.optJSONObject(i)?.optString("url") == tab.url) {
            showToast("Already saved"); return
        }
        bookmarks.put(JSONObject().put("url", tab.url).put("title", tab.title))
        prefs.edit().putString("bookmarks", bookmarks.toString()).apply()
        showToast("Bookmark saved")
    }

    private fun showBookmarks() {
        val content = dialogContent()
        val bookmarks = loadArray("bookmarks")
        for (i in bookmarks.length() - 1 downTo 0) {
            val item = bookmarks.optJSONObject(i) ?: continue
            val url = item.optString("url")
            content.second.addView(listRow(item.optString("title", url), url) { loadInActive(url) })
        }
        if (bookmarks.length() == 0) content.second.addView(label("No saved blocks yet. Tap ★ on a page.", 13, color(R.color.paper), false))
        AlertDialog.Builder(this).setTitle("Saved blocks · Bookmarks").setView(content.first).setNegativeButton("DONE", null).show()
    }

    private fun showSessions() {
        val content = dialogContent()
        content.second.addView(label("Your open tabs are saved automatically. Gecko sessions keep their navigation history, scroll and form state when GeckoView provides a session snapshot.", 12, color(R.color.paper), false))
        content.second.addView(actionButton("SAVE SESSION NOW", color(R.color.grass), Color.WHITE) { persistTabs(); showToast("Session saved") })
        content.second.addView(actionButton("RESTORE LAST SESSION", color(R.color.dirt), Color.WHITE) { restoreLastSession(); showToast("Last session restored") })
        AlertDialog.Builder(this).setTitle("World saves · Sessions").setView(content.first).setNegativeButton("DONE", null).show()
    }

    private fun restoreLastSession() {
        val saved = prefs.getString("open_tabs", null)
        if (saved.isNullOrBlank()) {
            showToast("No saved session found")
            return
        }
        tabs.toList().forEach { tab ->
            try { tab.geckoSession?.close() } catch (_: Throwable) {}
            try { tab.webView?.stopLoading(); tab.webView?.destroy() } catch (_: Throwable) {}
        }
        tabs.clear()
        activeTab = null
        browserArea.removeAllViews()
        restoreTabs()
    }

    private fun showDownloads() {
        val content = dialogContent()
        content.second.addView(label("Downloaded files are saved to Android Downloads. Export copies a file to a folder you choose.", 11, color(R.color.grass_light), false))
        val stored = loadArray("gecko_downloads")
        for (i in stored.length() - 1 downTo 0) {
            val item = stored.optJSONObject(i) ?: continue
            val uri = item.optString("uri")
            val name = item.optString("name", "download")
            val mime = item.optString("mime", "application/octet-stream")
            content.second.addView(downloadRow(name, "Saved by Gecko engine", {
                openUri(Uri.parse(uri), mime)
            }, {
                exportSource = Uri.parse(uri); exportName = name; launchExport()
            }, {
                try { contentResolver.delete(Uri.parse(uri), null, null) } catch (_: Throwable) {}
                removeStoredDownload(uri)
                showDownloads()
            }))
        }
        val cursor: Cursor? = try { dm.query(DownloadManager.Query()) } catch (_: Throwable) { null }
        var systemDownloadCount = 0
        cursor?.use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val doneCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            while (c.moveToNext()) {
                systemDownloadCount++
                val id = c.getLong(idCol)
                val title = c.getString(titleCol) ?: "Download $id"
                val status = when (c.getInt(statusCol)) {
                    DownloadManager.STATUS_SUCCESSFUL -> "Complete"
                    DownloadManager.STATUS_FAILED -> "Failed"
                    DownloadManager.STATUS_PAUSED -> "Paused"
                    DownloadManager.STATUS_PENDING -> "Waiting"
                    DownloadManager.STATUS_RUNNING -> "Downloading"
                    else -> "Unknown"
                }
                val total = if (totalCol >= 0) c.getLong(totalCol) else -1L
                val done = if (doneCol >= 0) c.getLong(doneCol) else 0L
                val detail = if (total > 0) "$status · ${done / 1024} / ${total / 1024} KB" else status
                content.second.addView(downloadRow(title, detail, {
                    val uri = dm.getUriForDownloadedFile(id)
                    if (uri != null) openUri(uri, dm.getMimeTypeForDownloadedFile(id) ?: "*/*") else showToast("File is not ready")
                }, {
                    val uri = dm.getUriForDownloadedFile(id)
                    if (uri != null) { exportSource = uri; exportName = title; launchExport() } else showToast("File is not ready")
                }, {
                    dm.remove(id); showDownloads()
                }))
            }
        }
        if (stored.length() == 0 && systemDownloadCount == 0) {
            content.second.addView(label("Nothing downloaded yet.", 13, color(R.color.paper), false))
        }
        AlertDialog.Builder(this).setTitle("Chest · Downloads").setView(content.first).setNegativeButton("DONE", null).show()
    }

    private fun downloadRow(name: String, detail: String, open: () -> Unit, export: () -> Unit, delete: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = blockDrawable(color(R.color.stone), color(R.color.dirt))
        }
        row.addView(label(name, 13, color(R.color.paper), true))
        row.addView(label(detail, 10, color(R.color.grass_light), false))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        actions.addView(actionButton("OPEN", color(R.color.grass), Color.WHITE, open))
        actions.addView(actionButton("EXPORT", color(R.color.dirt), Color.WHITE, export))
        actions.addView(actionButton("DELETE", 0xff81433b.toInt(), Color.WHITE, delete))
        row.addView(actions)
        val params = LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(7)
        row.layoutParams = params
        return row
    }

    private fun queueWebViewDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val uri = Uri.parse(url)
            val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(uri)
                .setTitle(name)
                .setDescription("Downloading with Blockert Browser")
                .setMimeType(mimeType ?: "application/octet-stream")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
            CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
            dm.enqueue(request)
            showToast("Download added to Downloads")
        } catch (e: Exception) {
            showToast("Could not start download: ${e.message}")
        }
    }

    private fun saveGeckoResponse(response: WebResponse) {
        val source: InputStream = response.body ?: return
        val uri = Uri.parse(response.uri)
        val name = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "blockert-download"
        val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"
        thread(name = "blockert-download") {
            var destination: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                destination = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Android did not create a download file")
                contentResolver.openOutputStream(destination!!, "w")!!.use { output -> source.use { input -> input.copyTo(output) } }
                val ready = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                contentResolver.update(destination!!, ready, null, null)
                val saved = loadArray("gecko_downloads")
                saved.put(JSONObject().put("uri", destination.toString()).put("name", name).put("mime", mime))
                prefs.edit().putString("gecko_downloads", saved.toString()).apply()
                runOnUiThread { showToast("Saved to Downloads: $name") }
            } catch (e: Exception) {
                try { destination?.let { contentResolver.delete(it, null, null) } } catch (_: Throwable) {}
                try { source.close() } catch (_: Throwable) {}
                runOnUiThread { showToast("Download failed: ${e.message}") }
            }
        }
    }

    private fun removeStoredDownload(uri: String) {
        val old = loadArray("gecko_downloads")
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("uri") != uri) next.put(item)
        }
        prefs.edit().putString("gecko_downloads", next.toString()).apply()
    }

    private fun openUri(uri: Uri, mime: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Throwable) { showToast("No app can open this file") }
    }

    private fun launchExport() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, exportName)
        }
        try { startActivityForResult(intent, REQUEST_EXPORT) }
        catch (_: Throwable) { showToast("File picker unavailable") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_FILE_CHOOSER) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        } else if (requestCode == REQUEST_EXPORT && resultCode == RESULT_OK && data?.data != null) {
            val source = exportSource ?: return
            val destination = data.data!!
            thread(name = "blockert-export") {
                try {
                    contentResolver.openInputStream(source).use { input ->
                        contentResolver.openOutputStream(destination, "w").use { output ->
                            requireNotNull(input).copyTo(requireNotNull(output))
                        }
                    }
                    runOnUiThread { showToast("Exported ${exportName}") }
                } catch (e: Exception) {
                    runOnUiThread { showToast("Export failed: ${e.message}") }
                }
            }
            exportSource = null
        }
    }

    private fun showEngineDialog() {
        val options = arrayOf("Mozilla GeckoView · bundled open-source engine", "Android System WebView · fallback")
        val current = if (preferredEngine() == ENGINE_GECKO) 0 else 1
        AlertDialog.Builder(this).setTitle("Choose page engine")
            .setSingleChoiceItems(options, current) { dialog, which ->
                val selected = if (which == 0 && geckoRuntime != null) ENGINE_GECKO else ENGINE_SYSTEM
                prefs.edit().putString("engine", selected).apply()
                dialog.dismiss()
                showToast("Engine set for new tabs")
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun preferredEngine(): String {
        val selected = prefs.getString("engine", ENGINE_GECKO) ?: ENGINE_GECKO
        return if (selected == ENGINE_GECKO && geckoRuntime != null) ENGINE_GECKO else ENGINE_SYSTEM
    }

    private fun recordHistory(title: String, url: String) {
        if (!initialUrlIsHttp(url)) return
        val history = loadArray("history")
        val last = history.optJSONObject(history.length() - 1)
        if (last?.optString("url") == url) return
        history.put(JSONObject().put("url", url).put("title", title.ifBlank { url }).put("time", System.currentTimeMillis()))
        while (history.length() > MAX_HISTORY) history.remove(0)
        prefs.edit().putString("history", history.toString()).apply()
    }

    private fun persistTabs() {
        if (!::root.isInitialized) return
        val array = JSONArray()
        tabs.forEach { tab ->
            array.put(JSONObject()
                .put("id", tab.id)
                .put("engine", tab.engine)
                .put("url", tab.url)
                .put("title", tab.title)
                .put("state", tab.savedGeckoState ?: ""))
        }
        prefs.edit().putString("open_tabs", array.toString()).putString("active_tab", activeTab?.id ?: "").apply()
    }

    private fun loadArray(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Throwable) { JSONArray() }

    private fun dialogContent(): Pair<ScrollView, LinearLayout> {
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(color(R.color.grass_dark))
            addView(list)
        }
        return scroll to list
    }

    private fun listRow(title: String, detail: String, click: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = blockDrawable(color(R.color.stone), color(R.color.grass))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        row.addView(label(title, 13, color(R.color.paper), true))
        row.addView(label(detail, 10, 0xffc4d0c6.toInt(), false))
        val params = LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(7)
        row.layoutParams = params
        return row
    }

    private fun bottomButton(text: String, glyph: String, click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(3), dp(5), dp(3))
            setOnClickListener { click() }
        }
        box.addView(label(glyph, 19, color(R.color.grass_light), true).apply { gravity = Gravity.CENTER })
        box.addView(label(text, 8, color(R.color.paper), true).apply { gravity = Gravity.CENTER })
        box.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
        return box
    }

    private fun actionButton(text: String, bg: Int, fg: Int, click: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(fg)
            isAllCaps = false
            minHeight = dp(38)
            minimumHeight = dp(38)
            minWidth = dp(38)
            setPadding(dp(7), 0, dp(7), 0)
            background = blockDrawable(bg, color(R.color.grass_dark))
            setOnClickListener { click() }
        }
    }

    private fun label(text: String, size: Int, fg: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(fg)
        typeface = if (bold) Typeface.create("monospace", Typeface.BOLD) else Typeface.MONOSPACE
        setPadding(0, dp(2), 0, dp(2))
    }

    private fun blockDrawable(fill: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        setStroke(dp(2), stroke)
        cornerRadius = dp(2).toFloat()
    }

    private fun color(id: Int): Int = getColor(id)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun showToast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        val tab = activeTab
        if (tab?.geckoSession != null && tab.canGoBack) {
            tab.geckoSession?.goBack()
            return
        }
        if (tab?.webView?.canGoBack() == true) {
            tab.webView?.goBack()
            return
        }
        super.onBackPressed()
    }

    override fun onPause() {
        persistTabs()
        activeTab?.geckoSession?.flushSessionState()
        super.onPause()
    }

    override fun onDestroy() {
        persistTabs()
        super.onDestroy()
    }
}
