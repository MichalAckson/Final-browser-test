plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chatgpt.blockertbrowser"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.chatgpt.blockertbrowser"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    packaging {
        jniLibs { useLegacyPackaging = true }
        resources.excludes += setOf("META-INF/DEPENDENCIES")
    }
}

dependencies {
    // Mozilla's embeddable Gecko engine: bundled with the app, independent of the Chrome app.
    implementation("org.mozilla.geckoview:geckoview:159.0.20261102144711")
}
