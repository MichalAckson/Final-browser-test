# Blockert Browser

A native Android browser project with a Minecraft-inspired block UI, original voxel grass-block artwork, independent browser tabs, persistent browsing history, bookmarks, session restoration, and an in-app downloads manager.

## Rendering engine

- **Default: Mozilla GeckoView 159.0.20261102144711.** GeckoView bundles Mozilla's Gecko engine in the app; it is an open-source, embeddable Android browser engine under MPL 2.0. It does not launch Chrome or use Chrome Custom Tabs.
- **Fallback: Android System WebView.** Choose this from the gear menu. It is still rendered in-app and does not launch the Chrome browser UI. The actual WebView implementation is the Android provider installed on the device.

Application ID / package name: `com.chatgpt.blockertbrowser`. The project targets Android 14+ well and sets minSdk 29. GeckoView is used as a top-level browser view, not an iframe. As a result, a site that blocks iframe embedding can still be visited as a normal top-level page. This does not bypass login checks, network restrictions, certificate errors, site access controls, or other server rules.

## Browser features in the project

- Multiple independent GeckoSession / WebView instances, one per tab.
- Visual card-based tab switcher with close and switch actions.
- Back, forward, reload, address/search, home and new-tab controls.
- Persistent session snapshots for GeckoView, including navigation history and session state when GeckoView supplies a snapshot; WebView fallback restores the last URL.
- Persistent browser history and bookmarks.
- Download manager screen with open, delete and export actions.
- GeckoView download response streams copied to Android's public Downloads collection via MediaStore.
- WebView downloads queued through Android DownloadManager, including User-Agent and available cookies.
- Android Storage Access Framework export to a folder/file chosen by the user.
- File upload chooser support in the WebView fallback.
- TLS certificate errors are cancelled in the WebView fallback; mixed content is not enabled.
- Original generated icon artwork, adaptive launcher icon resources, and preview thumbnail.

## Build setup

This environment does **not** contain the Android SDK, Android build-tools, Gradle distribution, GeckoView AAR, or a working Android emulator. Its shell cannot resolve external package hosts, so it cannot download those dependencies here. Therefore this folder is a buildable Android Studio project, **not a compiled or device-tested APK**. Do not install the earlier `Blocker.apk`: its hand-authored DEX used the wrong register numbers for the Activity and context in `onCreate`, which can cause a verifier/startup crash.

To build the project in an Android development environment:

1. Open this folder in Android Studio.
2. Use JDK 17 and allow Gradle to sync. The project pins Gradle 9.3.1 in `gradle/wrapper/gradle-wrapper.properties`, Android Gradle Plugin 9.1.1, Kotlin Android plugin 2.4.21 and compile SDK 36.
3. Gradle needs network access to fetch the Android and Kotlin plugins plus Mozilla's GeckoView artifact from `https://maven.mozilla.org/maven2/`.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The project deliberately uses source-level Android/Kotlin code and the official GeckoView integration rather than hand-assembling DEX. The generated APK still needs installation and runtime testing on a real device before it should be treated as a release.

## GeckoView references

Mozilla's official quick start documents the Maven repository, Java 17 compatibility, dependency setup and GeckoRuntime/GeckoSession/GeckoView initialization. See the references listed in `SOURCES.md`.

## Files

- `app/src/main/java/com/blockert/browser/MainActivity.kt`: native browser UI and logic.
- `app/src/main/AndroidManifest.xml`: launcher, app label, permissions and URL intents.
- `app/src/main/res/`: pixel/block icon resources, colors and theme.
- `assets/BlockertBrowser-preview.png`: original art/thumbnail.


## Newly APK Builder compatibility patch (v0.2.1)

The first Newly attempt reached image preparation but failed with `Failed to find package 'platforms;android-37'`. This project now compiles against Android 16 / API 36. Android Gradle Plugin 9.1.1 supports API 37 and lower, so API 36 is within its supported range. The app still targets API 35 and keeps its minSdk at 29; only the compile SDK was lowered to avoid the builder's unavailable API 37 platform package.
