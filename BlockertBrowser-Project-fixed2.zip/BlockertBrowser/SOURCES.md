# Technical sources and licenses

1. Mozilla GeckoView getting started: https://firefox-source-docs.mozilla.org/mobile/android/geckoview/consumer/geckoview-quick-start.html
   Covers the Mozilla Maven repository, Java 17 compatibility, the GeckoView dependency and creating a GeckoRuntime, GeckoSession and GeckoView.
2. GeckoView architecture: https://firefox-source-docs.mozilla.org/mobile/android/geckoview/contributor/geckoview-architecture.html
   Explains that GeckoView embeds Gecko, GeckoRuntime is shared by the app, GeckoSession represents a tab/session, and app code must manage history/session state.
3. GeckoView API: https://mozilla.github.io/geckoview/javadoc/mozilla-central/org/mozilla/geckoview/GeckoSession.html
4. GeckoView session state: https://mozilla.github.io/geckoview/javadoc/mozilla-central/org/mozilla/geckoview/GeckoSession.SessionState.html
5. Android DownloadManager: https://developer.android.com/reference/android/app/DownloadManager
6. Android WebView: https://developer.android.com/reference/android/webkit/WebView
7. Android WebView state and lifecycle: https://developer.android.com/develop/ui/views/layout/webapps/managing-webview

GeckoView is distributed by Mozilla under the Mozilla Public License 2.0. This project consumes the published GeckoView binary dependency; it does not claim ownership of GeckoView. Its source and license are available from Mozilla.
