#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 9.3.1 is required. Install it or open this project in Android Studio and select Gradle 9.3.1." >&2
  exit 127
fi
exec gradle --no-daemon :app:assembleDebug "$@"
